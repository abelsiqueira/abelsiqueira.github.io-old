% Testando QR: Criaremos uma matriz e calcularemos a norma de
% Q*R-A. Faremos isso N vezes.

N = 50;
total = 0.0;

for k = 1:N
  m = 2*k;
  n = k;
  A = rand(m,n);
  [Q,R] = gram_sch(A);
  total = total + norm(Q*R-A);
  A = rand(m,m);
  [Q,R] = gram_sch(A);
  total = total + norm(Q*R-A);
end
printf('Teste QR: residuo %e\n', total/N);
