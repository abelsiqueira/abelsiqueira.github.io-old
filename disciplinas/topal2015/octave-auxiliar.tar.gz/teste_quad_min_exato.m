N = 30;

total = 0;
for k = 1:N
  m = 2*k;
  n = k/10+2;

  x = unique(sort(rand(m,1)))*n;
  while length(x) < m
    x = unique(sort(rand(m,1)))*n;
  end

  alpha_sol = 10*(2*rand(n,1)-1);
  y = zeros(m,1);
  F = cell(n,1);
  for i = 1:n
    F{i} = @(x) x.^(i-1);
    y = y + alpha_sol(i)*F{i}(x);
  end
  [alpha, r] = quad_min(x,y,F);

  % solução esperada
  r_sol = y*0;

  total = total + norm(alpha_sol-alpha) + norm(r-r_sol);
end

printf("Teste de Quadrados mínimos com solução exata\nResiduo ");
disp(total/N);
