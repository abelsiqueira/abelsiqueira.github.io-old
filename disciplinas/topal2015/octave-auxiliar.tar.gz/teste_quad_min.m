N = 30;

total = 0;
for k = 1:N
  m = 2*k;
  n = k/10+2;

  x = (1:m)';
  y = rand(m,1);

  F = cell(n,1);
  for i = 1:n
    F{i} = @(x) x.^(i-1);
  end

  [alpha, r] = quad_min(x,y,F);

  % solução esperada
  warning off;
  F = ((1:m)').^(0:n-1);
  warning on;
  alpha_sol = F\y;
  r_sol = y - F*alpha_sol;

  total = total + norm(alpha_sol-alpha) + norm(r-r_sol);
end

printf("Teste de Quadrados mínimos\nResiduo ");
disp(total/N);
