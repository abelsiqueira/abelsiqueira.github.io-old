% Testando solução do SL com matriz triangular superior:
% Criaremos uma matriz A, calcularemos QR para obter uma
% matriz triangular superior. Criaremos e = [1;1;1;...;1].
% Criaremos b = R*e.
% Faremos isso N vezes.

N = 100;
total = 0.0;

for n = 1:N
  A = triu(rand(n,n));
  while rank(A) < n
    A = triu(rand(n,n));
  end
  e = ones(n,1);
  b = A*e;
  x = tri_sup(A,b); % x deve ser igual a e, e A*x = b
  total = total + norm(A*x-b) + norm(x-e);
end
printf('Teste TriSup: residuo %e\n', total/N);
