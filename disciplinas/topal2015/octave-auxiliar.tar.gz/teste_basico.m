x = [0;   1;   2;   3;   4;   5;   6];
y = [1; 2.1; 3.2; 4.3; 5.4; 6.5; 7.6];

f1 = @(x) ones(size(x));
f2 = @(x) x;
F = {f1, f2};

[alpha, r] = quad_min(x,y,F);

% solução esperada
alpha_sol = [1;1.1];
r_sol = y*0;

disp("Teste básico de quadrados mínimos:")
printf("|alpha_sol - alpha| = ")
disp(norm(alpha_sol-alpha))
printf("|r - r_sol| = ")
disp(norm(r-r_sol));
