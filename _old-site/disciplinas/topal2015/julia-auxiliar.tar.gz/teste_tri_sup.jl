include("tri_sup.jl")

N = 100
total = 0.0

for n = 1:N
  A = triu(rand(n,n))
  e = ones(n)
  b = A*e
  x = tri_sup(A,b)
  total += norm(A*x-b) 
end
print("Teste TriSup: residuo: ")
println(total/N)
