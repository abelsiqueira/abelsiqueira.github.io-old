include("quad_min.jl")

N = 30

total = 0
for k = 1:N
  m = 2*k
  n = int(k/10)+2

  x = 1:m
  y = rand(m)

  F = Array(Function,n)
  for i = 1:n
    F[i] = x->x.^(i-1)
  end

  (alpha, r) = quad_min(x, y, F)

  # solução esperada
  F = (1:m).^(0:n-1)'
  alpha_sol = F\y
  r_sol = y - F*alpha_sol

  total += norm(alpha_sol-alpha) + norm(r-r_sol)
end

println("Teste de Quadrados mínimos")
print("Resíduo ")
println(total/N)
