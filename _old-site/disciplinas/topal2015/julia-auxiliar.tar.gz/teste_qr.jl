include("gram_sch.jl")

N = 50
total = 0.0
for k = 1:N
  m = 2*k
  n = k
  A = rand(m,n)
  (Q,R) = gram_sch(A)
  total += norm(Q*R-A)
  A = rand(m,m)
  (Q,R) = gram_sch(A)
  total += norm(Q*R-A)
end

println("Teste QR: residuo ")
println(total/N)
