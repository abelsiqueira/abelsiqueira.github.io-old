include("quad_min.jl")

N = 30

total = 0
for k = 1:N
  m = 2*k
  n = int(k/10)+2

  x = unique(sort(rand(m)))*n
  while length(x) < m
    x = unique(sort(rand(m)))*n
  end

  alpha_sol = 10*(2*rand(n)-1)
  y = zeros(m)

  F = Array(Function,n)
  for i = 1:n
    F[i] = x->x.^(i-1)
    y += alpha_sol[i]*F[i](x)
  end

  (alpha, r) = quad_min(x, y, F)

  # solução esperada
  r_sol = zeros(size(y))

  total += norm(alpha_sol-alpha) + norm(r-r_sol)
end

println("Teste de Quadrados mínimos com solução exata")
print("Resíduo ")
println(total/N)
